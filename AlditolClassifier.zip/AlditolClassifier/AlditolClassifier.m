% STEP 1: Train Classifier
% Extract predictors and response
% This code processes the data into the right shape for training the
% model.
inputTable = readtable('alditols_trainingdataset.xlsx');% Enter the file name to index the training dataset
predictorNames = {'ratio', 'std', 'peak', 'FWHM', 'skew', 'kurt', 'Time'};
predictors = inputTable(:, predictorNames);
response = inputTable.label;
isCategoricalPredictor = [false, false, false, false, false, false, false];

% Train a classifier
% This code specifies all the classifier options and trains the classifier.
template = templateSVM(...
    'KernelFunction', 'polynomial', ...
    'PolynomialOrder', 2, ...
    'KernelScale', 'auto', ...
    'BoxConstraint', 1, ...
    'Standardize', true);
classificationSVM = fitcecoc(...
    predictors, ...
    response, ...
    'Learners', template, ...
    'Coding', 'onevsone', ...
    'ClassNames', categorical({'D-sorbitol'; 'L-sorbitol'; 'adonitol'; 'allitol'; 'arabitol'; 'dulcitol'; 'erythritol'; 'glycerol'; 'iditol'; 'mannitol'; 'talitol'; 'threitol'; 'xylitol'}));

% Create the result struct with predict function
predictorExtractionFcn = @(t) t(:, predictorNames);
svmPredictFcn = @(x) predict(classificationSVM, x);
trainedClassifier.predictFcn = @(x) svmPredictFcn(predictorExtractionFcn(x));

% Add additional fields to the result struct
trainedClassifier.RequiredVariables = {'FWHM', 'Time', 'kurt', 'peak', 'ratio', 'skew', 'std'};
trainedClassifier.ClassificationSVM = classificationSVM;

% Extract predictors and response
% This code processes the data into the right shape for training the
% model.
inputTable = readtable('alditols_trainingdataset.xlsx');% Enter the file name to index the training dataset
predictorNames = {'ratio', 'std', 'peak', 'FWHM', 'skew', 'kurt', 'Time'};
predictors = inputTable(:, predictorNames);
response = inputTable.label;
isCategoricalPredictor = [false, false, false, false, false, false, false];

% Perform cross-validation
partitionedModel = crossval(trainedClassifier.ClassificationSVM, 'KFold', 10);

% Compute validation predictions
[validationPredictions, validationScores] = kfoldPredict(partitionedModel);

% Compute validation accuracy
validationAccuracy_retrain = 1 - kfoldLoss(partitionedModel, 'LossFun', 'ClassifError');

% Compute resubstitution accuracy
resubstitutionAccuracy_retrain = 1 - resubLoss(trainedClassifier.ClassificationSVM);

% Export confusion matrix 
validationPredictions_cellstr=cellstr(validationPredictions);
cm = confusionchart(response,validationPredictions_cellstr, ...
    'Title','Confusion Matrix of the SVM', ...
    'RowSummary','row-normalized');

%STEP 2: Make prediction with the returned 'trainedClassifier' on testing dataset

mix_table = readtable('mix13-13_feat.xlsx');%Import test dataset
prediction_results = ("SVMmix13_13_prediction");
label_predict = table(trainedClassifier.predictFcn(mix_table),'VariableNames',prediction_results);%Make prediction and output the labels
filename1 = 'SVMmix13_1_3_6_13_results_predict.xlsx';%file name
writetable(label_predict,filename1,'Sheet',4,'Range','A1');%Export the predicted labels to an xlsx file, change the sheet number to export the predicted results of different testing datasets into the same file

predict=trainedClassifier.predictFcn(mix_table);
predict_results=table(tabulate(predict));%Count the number and proportion of each label in the result matrix "predict"
filename2 = 'SVMmix13_1_3_6_13_proportion_predict.xlsx';%file name
writetable(predict_results,filename2,'Sheet',4,'Range','A1');%Export the predicted labels to an xlsx file, change the sheet number to export the predicted results of different testing datasets into the same file


% STEP 3: Plot learning curve

param = inputTable(:,8);
a = height(param);%The total number of samples in the training dataset,4962
x = [];
y_resub = [];
y_validation = [];
for i = 50:50:a
    x = [x i]; 
    NeedSimple = inputTable(randi(a,1,i),:);%Randomly select i rows of inputTable as the new training dataset to retrain the classifier
    predictorNames = {'ratio', 'std', 'peak', 'FWHM', 'skew', 'kurt', 'Time'};
    predictors = NeedSimple(:, predictorNames);
    response = NeedSimple.label;
    isCategoricalPredictor = [false, false, false, false, false, false, false];

    template = templateSVM(...
        'KernelFunction', 'polynomial', ...
        'PolynomialOrder', 2, ...
        'KernelScale', 'auto', ...
        'BoxConstraint', 1, ...
        'Standardize', true);
    classificationSVM = fitcecoc(...
        predictors, ...
        response, ...
        'Learners', template, ...
        'Coding', 'onevsone', ...
        'ClassNames', categorical({'D-sorbitol'; 'L-sorbitol'; 'adonitol'; 'allitol'; 'arabitol'; 'dulcitol'; 'erythritol'; 'glycerol'; 'iditol'; 'mannitol'; 'talitol'; 'threitol'; 'xylitol'}));

    predictorExtractionFcn = @(t) t(:, predictorNames);
    svmPredictFcn = @(x) predict(classificationSVM, x);
    trainedClassifier.predictFcn = @(x) svmPredictFcn(predictorExtractionFcn(x));

    trainedClassifier.RequiredVariables = {'FWHM', 'Time', 'kurt', 'peak', 'ratio', 'skew', 'std'};
    trainedClassifier.ClassificationSVM = classificationSVM;
   
 
    NeedSimple = inputTable(randi(a,1,i),:);%Randomly select i rows of inputTable as the new training dataset to retrain the classifier
    predictorNames = {'ratio', 'std', 'peak', 'FWHM', 'skew', 'kurt', 'Time'};
    predictors = NeedSimple(:, predictorNames);
    response = NeedSimple.label;
    isCategoricalPredictor = [false, false, false, false, false, false, false];

    % Perform cross-validation
    partitionedModel = crossval(trainedClassifier.ClassificationSVM, 'KFold', 10);

    % Compute validation predictions
    [validationPredictions, validationScores] = kfoldPredict(partitionedModel);

    % Compute validation accuracy
    validationAccuracy_retrain = 1 - kfoldLoss(partitionedModel, 'LossFun', 'ClassifError');%crosss-validation score

    % Compute resubstitution accuracy
    resubstitutionAccuracy_retrain = 1 - resubLoss(trainedClassifier.ClassificationSVM);%training score
    y_resub = [y_resub resubstitutionAccuracy_retrain];
    y_validation = [y_validation validationAccuracy_retrain];
end
result_resub = [x(:) y_resub(:)];
result_validation = [x(:) y_validation(:)];
tab1=table(result_resub(:,:));
tab2=table(result_validation(:,:));
filename3 = 'learning_curve_SVMclassifier_13alditol.xlsx';%file name
writetable(tab2,filename3,'Sheet',1,'Range','D1');%Output results to an xlsx file
writetable(tab1,filename3,'Sheet',1,'Range','A1');%Output results to an xlsx file