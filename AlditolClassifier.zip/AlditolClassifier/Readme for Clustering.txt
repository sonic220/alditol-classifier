Clustering
**************************************************************************************************************************************

1. Introduction

Clustering is a custom algorithm in MATLAB to clustering the blocking events of a zero-sugar drink using K-means clustering to extract the events of major components.

It includes functions as follows:
a. Assigns events to clusters and figure a scatter plot that contains the center point of each cluster 
b. Make a silhouette plot to measure how close each point in one cluster is to points in the neighboring clusters

2. Operating procedures:

-Unzip the AlditolClassifier.rar to local folder, and open the Clustering.m in MATLAB

-Enter the file name in line 1 to index the dataset to be clustered. // example: Mizone_feat.xlsx

-Enter the number of clusters that you want to create in line 4. // example: 3
-Adjust legend in line 10 to match the cluster number  

-Specify names for the .xlsx files of the results at line 11. // example: cluster_Mizone.xlsx

-Run Clustering.m

-Select File > Save As in the Figure windows to save the scatter plot and silhouette plot. Specify the saved file location, name, and type.
