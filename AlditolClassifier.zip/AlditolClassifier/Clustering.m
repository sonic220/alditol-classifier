input = readtable('Mizone_feat.xlsx');% Enter the file name to index the predicting dataset
rng default; % For reproducibility
X = input{:,1:2};% ratio and std
[idx,C] = kmeans(X,3);% 3 clusters
[silh2,h] = silhouette(X,idx,'sqeuclidean');% silhouette plot
figure % scatter plot
gscatter(X(:,1),X(:,2),idx,'bgm')
hold on
plot(C(:,1),C(:,2),'kx')
legend('Cluster 1','Cluster 2','Cluster 3','Cluster Centroid')
featurename = ["cluster"];
tab=table(idx(:,:),'VariableNames',featurename);
filename = 'cluster_Mizone.xlsx';
writetable(input,filename,'Sheet',1,'Range','A1');%Output features to an xlsx file
writetable(tab,filename,'Sheet',1,'Range','I1');%Output cluster label to the same xlsx file