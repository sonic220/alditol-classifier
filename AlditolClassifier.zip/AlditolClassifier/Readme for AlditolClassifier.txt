Alditol-Classifier
*********************************************************************************************************************************************************

1. Introduction

Alditol-Classifier is a machine learnig-based automatic identification system of alditols using MATLAB.

It contains three steps as follows:
 a. Train Classifier using training dataset
 b. Make predictions with the returned 'trainedClassifier' on predictive dataset
 c. Evaluate the classifier with the learning curve

2. Operating procedures:

-Unzip the AlditolClassifier.rar to local folder, and open the AlditolClassifier.m in MATLAB

-Enter the file name in line 5 and line 38 (step 1) to index the training dataset. // example: alditols_trainingdataset.xlsx
 -Enter the file name in line 64 (step 2) to index the predictive dataset. // example: mix_13-13_feat.xlsx

 -Enter a label corresponding to the predictive dataset at line 65 (step2) for the prediction result. // example: SVMmix13_13_prediction

 -Specify names for the .xlsx files of the predict results at line 67 and line 72 (step2). // example: SVMmix13_1_3_6_13_proportion_predict.xlsx
 -Specify a name for the .xlsx file of the learning curve at line 136 (step3). // example: learning_curve_SVMclassifier_13alditol.xlsx

 -Run AlditolClassifier.m
 -Record the value of the variable ‘validationAccuracy’ in the workspace, which is the validation accuracy of this classifier.

-Select File > Save As in the Figure window to save the confusion matrix. Specify the saved file location, name, and type.